export const SERVICES={promo:{name:'AjiraReady Quick-Start Guide',amount:199},readiness:{name:'Online Work Readiness',amount:299},'cv-profile':{name:'CV & Profile Enhancement',amount:699},blueprint:{name:'30-Day Action Blueprint',amount:1299}};
export function getService(_env,key){const service=SERVICES[key];return service?{...service,key}:null;}
