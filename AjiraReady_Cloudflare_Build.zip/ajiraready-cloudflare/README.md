# AjiraReady Kenya — Cloudflare build

Static-first Cloudflare Pages application owned by Juakali Development Agency.

## Current working slice

- Responsive marketing homepage
- Two-step readiness assessment with local scoring
- Foundation, Progressing, and Opportunity Ready paths
- Service-selection and application-review flow
- Privacy and contact information

## Secure backend

The project includes Cloudflare Pages Functions, a D1 schema, server-controlled prices, IntaSend hosted checkout, a protected webhook, independent payment verification, rate limiting and duplicate-fulfilment protection.

1. Create a D1 database named `ajiraready-orders`, bind it to the Pages project as `DB`, and run `migrations/0001_secure_orders.sql`.
2. Add encrypted production secrets `INTASEND_PUBLIC_KEY`, `INTASEND_SECRET_KEY`, `INTASEND_WEBHOOK_CHALLENGE`, and `RATE_LIMIT_SALT`.
3. Confirm the locked server catalogue: Quick-Start KSh 199, Readiness KSh 299, CV & Profile KSh 699, and Blueprint KSh 1,299.
4. In IntaSend, subscribe a `collection_event` webhook at `https://YOUR-DOMAIN/api/webhooks/intasend` using the same challenge.
5. For sandbox testing, use sandbox keys and set `INTASEND_API_BASE=https://sandbox.intasend.com/api/v1`. Omit that override in production.

Checkout stays safely closed until the database and public key are configured. Never place the IntaSend secret key or webhook challenge in browser JavaScript or commit them to the project.

## Local preview

Run any static web server from this directory, for example:

```sh
python3 -m http.server 4173
```
